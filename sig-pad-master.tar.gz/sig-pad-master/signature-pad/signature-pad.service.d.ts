export declare class SignaturePadService {
    constructor();
}
