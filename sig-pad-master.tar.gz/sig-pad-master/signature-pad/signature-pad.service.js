import { Injectable } from '@angular/core';
var SignaturePadService = (function () {
    function SignaturePadService() {
    }
    return SignaturePadService;
}());
export { SignaturePadService };
SignaturePadService.decorators = [
    { type: Injectable },
];
/** @nocollapse */
SignaturePadService.ctorParameters = function () { return []; };
//# sourceMappingURL=signature-pad.service.js.map