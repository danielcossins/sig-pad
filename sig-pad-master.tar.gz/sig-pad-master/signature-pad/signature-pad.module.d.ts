export declare class SignaturePadModule {
}
