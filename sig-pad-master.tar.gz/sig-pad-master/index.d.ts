export { SignaturePadModule } from './signature-pad/signature-pad.module';
export { SignaturePadComponent } from './signature-pad/signature-pad.component';
