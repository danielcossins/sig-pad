export * from './index';
//# sourceMappingURL=angular2-signature-pad.js.map